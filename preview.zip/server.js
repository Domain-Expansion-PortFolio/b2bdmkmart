const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const DEFAULT_PORT = 8000;
const PORTS = process.env.PORT ? [parseInt(process.env.PORT, 10)] : [8000, 3000];
const ROOT_DIR = fs.existsSync(path.resolve(__dirname, '..', 'assets')) ? path.resolve(__dirname, '..') : __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf'
};

function handleRequest(req, res) {
  const parsedUrl = url.parse(req.url);
  let pathname = decodeURIComponent(parsedUrl.pathname);

  // Enable CORS for external React ERP / z.ai apps
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // --- ERP INVENTORY API ROUTES ---
  if (pathname === '/api/inventory' && req.method === 'GET') {
    const catalogPath = path.join(ROOT_DIR, 'assets', 'erp-inventory-catalog.json');
    if (fs.existsSync(catalogPath)) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      fs.createReadStream(catalogPath).pipe(res);
      return;
    }
  }

  if (pathname === '/api/inventory/damage' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { sku_id, damaged_qty, reason } = JSON.parse(body);
        const catalogPath = path.join(ROOT_DIR, 'assets', 'erp-inventory-catalog.json');
        let catalog = JSON.parse(fs.readFileSync(catalogPath, 'utf8'));
        const item = catalog.find(p => p.sku_id === sku_id);
        if (item) {
          const qty = parseInt(damaged_qty, 10) || 1;
          item.damaged_stock = (item.damaged_stock || 0) + qty;
          item.sellable_stock = Math.max(0, (item.total_physical_stock || 0) - item.damaged_stock - (item.reserved_stock || 0));
          item.last_damage_reason = reason || 'Transport Breakage';
          item.last_updated_at = new Date().toISOString();
          fs.writeFileSync(catalogPath, JSON.stringify(catalog, null, 2), 'utf8');
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, item }));
          return;
        }
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'SKU not found' }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // Check direct preview pages with or without .html, with or without /preview/ prefix
  let cleanName = pathname.replace(/^\//, '').replace(/^preview\//, '').replace(/\.html$/, '');
  if (!cleanName) cleanName = 'index';

  const previewCandidate = path.join(__dirname, cleanName + '.html');
  if (fs.existsSync(previewCandidate) && fs.statSync(previewCandidate).isFile()) {
    fs.readFile(previewCandidate, (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Server Error: ' + err.message);
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(data);
    });
    return;
  }

  // Resolve file path from workspace root
  let filePath = path.join(ROOT_DIR, pathname.replace(/^\//, ''));

  // Security check: ensure path stays within ROOT_DIR
  if (!filePath.startsWith(ROOT_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Access Denied');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Check if file is in preview dir
      const previewFilePath = path.join(__dirname, pathname.replace(/^\//, ''));
      if (fs.existsSync(previewFilePath) && fs.statSync(previewFilePath).isFile()) {
        filePath = previewFilePath;
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('File Not Found: ' + pathname);
        return;
      }
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, { 'Content-Type': contentType });
    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
}

PORTS.forEach(port => {
  const server = http.createServer(handleRequest);
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`[DMK Mart Server] Port ${port} in use, skipping.`);
    } else {
      console.error(`[DMK Mart Server] Error on port ${port}:`, err);
    }
  });
  server.listen(port, () => {
    console.log(`[DMK Mart Server] Active at: http://localhost:${port}`);
  });
});
