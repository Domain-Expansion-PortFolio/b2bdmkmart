@echo off
title DMK Mart - B2B Wholesale Store Preview
echo ========================================================
echo        DMK MART - B2B WHOLESALE STORE PREVIEW
echo ========================================================
echo.
echo Option 1: Direct browser opening
echo Opening index.html in your default web browser...
start "" "%~dp0index.html"
echo.
echo Option 2: Running local Node.js server (if Node is installed)
where node >nul 2>nul
if %errorlevel% equ 0 (
    echo Starting Node.js preview server on port 8000...
    node "%~dp0server.js"
) else (
    echo Node.js not detected on system PATH.
    echo All preview pages are fully styled and work directly by opening HTML files!
    pause
)
