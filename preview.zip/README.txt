====================================================================
DMK MART - B2B WHOLESALE STORE PREVIEW PACKAGE
====================================================================

HOW TO VIEW:
-------------
METHOD 1: Instant Offline Browser Preview (No setup needed)
Simply double-click any of the HTML files in your browser (Chrome, Edge, Firefox, Safari).
Start with "index.html". All CSS styling is included inside the "css" folder!

METHOD 2: Running with Node.js Server
If you have Node.js installed, open terminal/command prompt in this folder and run:
    node server.js
Then visit: http://localhost:8000 in your browser.
(Alternatively, double-click START_PREVIEW.bat on Windows).

INCLUDED PREVIEW SCREENS:
-------------------------
1.  index.html            - Main Wholesale Storefront (Category grid, tiered pricing cards, zone selector)
2.  customer-portal.html  - Retailer / Buyer Dashboard (Order ledger, active shipments, invoices)
3.  salesman-portal.html  - Sales Rep Field Booking App (Beat mapping, quick orders, target tracker)
4.  admin-portal.html     - Super Admin Management Panel (Catalog, tiered pricing, stock, rep management)
5.  erp-inventory.html    - ERP Inventory & Damage Stock Manager (Warehouse stock, breakage logging)
6.  categories.html       - Wholesale Categories Catalog
7.  product-detail.html   - Volume Tier Product Details (Carton / pallet pricing calculator)
8.  cart.html             - B2B Bulk Cart with MOQ and GST Breakdown
9.  checkout.html         - B2B Checkout & Transport Dispatch
10. orders.html           - Order History & Invoice Tracker
11. login.html            - Wholesaler / Dealer Login Screen
12. register.html         - GST / Trade License Registration Screen
13. contact.html          - Wholesale Inquiry & Location Map
14. diwali.html           - Festival Promotional Offer Landing Page

STYLE ASSETS:
-------------
- css/dmk-modern-theme.css (Complete Modern Purple/Amber B2B Design System)
- css/bootstrap.min.css, main.css, responsive.css, spacing.css
- assets/ (Includes brand logo, favicon, banner, and ERP catalog data)
====================================================================
